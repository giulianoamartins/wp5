<?php

class Courses {

    public $fields = array(
        "area_course",
        "unit_course",
        "level_course",
        "coordinator_course",
        "formation_course",
        "duration_course",
        "modality_course",
        "workload_course",
        "hour_course",
        "mec_course",
        "cost_course",
        "activities",
        "location_course",
        "info_course",
        "link_course",
        "additional_information",
        "evaluation_course",
        "grid_course",
        "release_year",
        "blog_course",
        "course_recognition",
        "relation_course_",
        "relation_graduation_",
        "relation_phd_"
    );

    public function getCourses($options = array()) {

        $args = array("post_type" => "courses", "orderby" => "title", "order" => "ASC", "posts_per_page" => -1);

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);
    }

    public function getListCourses($options = array()) {

        $data = self::getCourses($options);

        $courses = array();

        while ($data->have_posts()) {
            $data->the_post();
            $courses[get_the_ID()] = get_the_title();
        }

        return $courses;
    }

    public function getCourseById($course_id) {

        $args = array("p" => $course_id);

        return new WP_Query($args);
    }

    public function getCoursesByUnit($unit_id = null, $options = array()) {

        $args = array(
            "post_type" => "courses",
            "orderby" => "title",
            "order" => "ASC",
            "posts_per_page" => -1,
            "meta_query" => array(
                array("key" => "unit_course",
                    "value" => $unit_id)
            )
        );

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);
    }

    public function getCoursesByArea($area_id = null, $options = array()) {

        $args = array(
            "post_type" => "courses",
            "orderby" => "title",
            "order" => "ASC",
            "posts_per_page" => -1,
            "meta_query" => array(
                array("key" => "area_course",
                    "value" => $area_id)
            )
        );

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);
    }

    
    public function getListCoursesByArea($area_id = null) {

        $data = self::getCoursesByArea($area_id);

        $courses = array();

        while ($data->have_posts()) {
            $data->the_post();
            $courses[get_the_ID()] = get_the_title();
        }

        return $courses;
    }

    public function getCoursesByLevel($level_id = null, $options = array()) {

        $args = array(
            "post_type" => "courses",
            "orderby" => "title",
            "order" => "ASC",
            "posts_per_page" => -1,
            "meta_query" => array(
                array("key" => "level_course",
                    "value" => $level_id)
            )
        );

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }
        //debug($args);
        return new WP_Query($args);
    }

    public function getCoursesByAreaAndLevel($area_id = null, $level_id = null, $options = array()) {


        $args = array(
            "post_type" => "courses",
            "orderby" => "title",
            "order" => "ASC",
            "posts_per_page" => -1,
            "meta_query" => array(
                array("key" => "area_course",
                    "value" => $area_id),
                array("key" => "level_course",
                    "value" => $level_id)
            )
        );

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);
    }

    public function getCourserByMeta($metaArr,$options=array()){

        $args = array(
            "post_type" => "courses",
            "orderby" => "title",
            "order" => "ASC",
            "posts_per_page" => -1
        );

        $args["meta_query"] = array();

        foreach($metaArr as $key => $value){

            $args["meta_query"][]= array(
                "key"=>$key,
                "compare"=>"=",
                "value"=>$value
            );

        }


        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);

    }

    public function createCustomPostType() {

        register_post_type('courses', array(
            'label' => 'Graduacao',
            'description' => 'Cadastro de Curso',
            'public' => true,
            'exclude_from_search' => false,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'rewrite' => array('slug' => 'graduacao'),
            'query_var' => true,
            'menu_position' => 10,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => get_bloginfo("stylesheet_directory") . '/wp5/img/icon-courses.png',
            'labels' => array(
                'name' => 'Graduaçao',
                'singular_name' => 'Graduaçao',
                'menu_name' => 'Graduaçao',
                'add_new' => 'Novo Curso',
                'add_new_item' => 'Novo Curso',
                'edit' => 'Editar',
                'edit_item' => 'Editar Curso',
                'new_item' => 'Novo Curso',
                'view' => 'Ver Curso',
                'view_item' => 'Ver Curso',
                'search_items' => 'Buscar Cursos',
                'not_found' => 'No Destaques Found',
                'not_found_in_trash' => 'No Destaques Found in Trash',
                'parent' => 'Parent Curso',
            ),
        ));

        add_filter('manage_edit-courses_columns',array(&$this,"manageCustomColumn"));
        add_action('manage_courses_posts_custom_column',array(&$this,"manageCustomColumnContent"),10,2);
        add_action('add_meta_boxes', array(&$this, 'addCustomFields'));
        add_action('save_post', array(&$this, 'saveCustomFields'));
    }
    public function manageCustomColumn($columns){
        
        unset($columns["date"]);
        
        $columns["unit"] = "Unidade";
        $columns["date"] = "Data";
        
        return $columns;
        
    }
    
    public function manageCustomColumnContent($column,$post_id){
        
        if($column=="unit"){
            $unit_id = get_post_meta($post_id,"unit_course",true);
            if($unit_id!=""){
                echo get_the_title($unit_id);
            }else{
                echo "";
            }
        }
        
    }

    public function addCustomFields() {

        add_meta_box("courseCustomFields", "Dados do Curso", array(&$this, "formCustomFields"), "courses", "normal", "low");
    }

    public function formCustomFields() {

        global $post;

        $data = get_post_custom($post->ID);


        foreach ($this->fields as $field) {
            $$field = (isset($data[$field])) ? $data[$field][0] : '';
        }

        $grid_course = (isset($data["grid_course"])) ? $data["grid_course"][0] : '';

        wp_nonce_field('my_meta_box_nonce', 'meta_box_nonce');

        $argsAreas = array("orderby" => "title", "order" => "asc");
        $areas = Areas::getListAreas($argsAreas);

        $argsLevels = array("orderby" => "title", "order" => "asc");
        $levels = Levels::getListLevels($argsLevels);
       
        $argsCourses = array("orderby" => "title","order" => "asc");
        $courses = Courses::getCourses($argsCourses);

        $argsGraduations = array("orderby" => "title","order" => "asc");
        $graduations = Graduations::getGraduation($argsGraduations);

        $argsPhds = array("orderby" => "title","order" => "asc");
        $phds = Phds::getPhds($argsPhds);
        
        $argsUnits = array();
        $current_user = wp_get_current_user();
        $unit_profile = get_user_meta($current_user->data->ID,"unit_profile",true);
        
        if(isset($current_user->caps['marketing']) && ($current_user->caps['marketing'])){
            $argsUnits["p"] = $unit_profile;
        }else{
            $argsUnits = array("orderby" => "title", "order" => "asc");
        }
        
        $units = Units::getListUnits($argsUnits);

        $argsCoordinators = array("orderby" => "title", "order" => "asc");
        $coordinators = Coordinators::getListCoordinators($argsCoordinators);
        ?>

        <p>
            <label for="areaCourse">Area do Conhecimento: </label>
            <select name="area_course" style="width:300px" id="areaCourse">
                <option value="">Selecione uma Área</option>
                <?php foreach ($areas as $key => $area) { ?>
                    <option value="<?php echo $key; ?>" <?php echo ($area_course == $key) ? 'selected="selected"' : ''; ?>><?php echo $area; ?></option>
                <?php } ?>
            </select>
        </p>
        <p>
            <label for="areaCourse">Nível de Ensino: </label>
            <select name="level_course" style="width:300px" id="levelCourse">
                    <option value="58">Graduação</option>
            </select>
        </p>
        <p>
            <label for="unitCourse">Unidade: </label>
            <select name="unit_course" style="width:300px" id="unitCourse">
                <option value="">Selecione uma Unidade</option>
                <?php foreach ($units as $key => $unit) { ?>
                    <option value="<?php echo $key; ?>" <?php echo ($unit_course == $key) ? 'selected="selected"' : ''; ?>><?php echo $unit; ?></option>
                <?php } ?>
            </select>
        </p>
        <p>
            <label for="coordinatorCourse">Coordenador: </label>
            <input type="text" name="coordinator_graduation" id="coordinatorCourse" value="<?php echo $coordinator_graduation; ?>" style="width:300px"/>          
        </p>   
        <p>
            <label for="durationCourse">Titulação:</label>
            <input type="text" name="formation_course" id="durationCourse" value="<?php echo $formation_course; ?>" style="width:300px"/>
        </p>
         <p>
            <label for="releaseYear">Ano de Lançamento:</label>
            <input type="text" name="release_year" id="releaseYear" value="<?php echo $release_year; ?>" style="width:300px"/>
        </p>
        <p>
            <label for="hourCourse">Periodo:</label>
            <input type="text" name="hour_course" id="hourCourse" value="<?php echo $hour_course; ?>" style="width:300px"/>
        </p>
        <p>
            <label for="link_course"style="font-weight:800;font-size:18px;">Link Inscrição:</label>
            <input type="text" name="link_course" id="link_course" value="<?php echo $link_course; ?>" style="width:300px"/>
        </p>
        <p>
            <label for="costCourse">Investimento:</label>
            <?php wp_editor($cost_course, "cost_course", array("textarea_name" => "cost_course")); ?>
        </p>

        <p>
            <label for="durationCourse">Duração do curso: </label>
            <input type="text" name="duration_course" id="durationCourse" value="<?php echo $duration_course; ?>" style="width:300px"/>
        </p>
        <p>
            <label for="workloadCourse">Horário das aulas: </label>
            <input type="text" name="workload_course" id="workloadCourse" value="<?php echo $workload_course; ?>" style="width:300px"/>
        </p>
       <p>           
            <label for="workloadCourse">Modalidade: </label>
            <select name="modality_course">
                <option value="">Selecione...</option>
                <option value="1" <?php echo ( $modality_course == 1) ? 'selected="selected"' : '' ?> >A Distância</option>
                <option value="2" <?php echo ( $modality_course == 2) ? 'selected="selected"' : '' ?> >Presencial</option>
                <option value="3" <?php echo ( $modality_course == 3) ? 'selected="selected"' : '' ?> >Stricto Senso</option>
            </select>            
        </p>
        
        <p>
            <label for="mecCourse">Reconhecimento: </label>
            <input type="text" name="course_recognition" id="courseRecognition" value="<?php echo $course_recognition; ?>" style="width:300px"/>
        </p>
        <p>
            <label for="mecCourse">Avaliação do MEC: </label>
            <input type="text" name="mec_course" id="mecCourse" value="<?php echo $mec_course; ?>" style="width:300px"/>
        </p>
        <p>
            <label for="evaluationMecCourse">Fale com o Coordenador: </label>
            <input type="text" name="evaluation_course" id="evaluationMecCourse" value="<?php echo $evaluation_course; ?>" style="width:300px"/>
        </p>
        
        <p>
            <label for="locationCourse">Atividades do Curso: </label><br/>
            <?php wp_editor($activities, "activities", array("textarea_name" => "activities")); ?>
        </p>

        <p>
            <label for="locationCourse">Você Sabia : </label><br/>
            <?php wp_editor($location_course, "locationCourse", array("textarea_name" => "location_course")); ?>
        </p>
         <p>
            <label for="additionalinformation">Informações Adicionais: </label><br/>
            <?php wp_editor($additional_information, "additionalinformation", array("textarea_name" => "additional_information")); ?>
        </p>
        
        <p>    
        <h3 class="hndle">Cursos de graduação relacionados:</h3>         
        <ul>
        <br/>

        <?php

            $id_course_current = $_GET['post'];

            $i=0;
            foreach ($courses->posts as $key => $course):
                $id_course = $course->ID;

                $url = get_post_permalink($id_course);

                    $results = get_post_meta($id_course_current, 'relation_course_'.$i, true);

                    $val_grad = explode('|', $results);
                    ?>         
                    <li style="font-size:14px;"><p><?php echo $course->post_title; ?></p></li>
                    <div class="status" style="position: relative;right: 225px;top: -25px;float: right;">
                        <label><input type="radio" name="data[relation_course_<?php echo $i; ?>]" 
                            value="<?php echo $course->ID; ?>|<?php echo $url; ?>|<?php echo $course->post_title; ?>"
                            <?php echo ($val_grad[0] == $id_course) ? 'checked="checked"' : '' ?>/> 
                            Sim
                        </label>
                        <label><input type="radio" name="data[relation_course_<?php echo $i; ?>]" value="0" <?php echo ($val_grad[0] != $id_course) ? 'checked="checked"' : '' ?> />Não</label>
                    </div>
                    <hr>
                <?php
                $i++;
            endforeach;
        wp_reset_postdata();
        ?>
        </ul>          
        </p>

        <p>    
        <h3 class="hndle">Cursos de Pós-graduação relacionados:</h3>         
            <ul>
            <br/>
            <?php
                $i=0;
                foreach ($graduations->posts as $key => $graduation):

                    $id_graduation = $graduation->ID;

                    $url = get_post_permalink( $id_graduation );

                    $args = get_post_meta($id_course_current, 'relation_graduation_'.$i, true);
                    
                    $val_pos = explode('|', $args);

                    ?>         
                    <li style="font-size:14px;"><p><?php echo $graduation->post_title; ?></p></li>
                        <div class="status" style="position: relative;right: 225px;top: -25px;float: right;">
                            <label><input type="radio" name="data[relation_graduation_<?php echo $i; ?>]" 
                                value="<?php echo $graduation->ID; ?>|<?php echo $url; ?>|<?php echo $graduation->post_title; ?>"
                                <?php echo ($val_pos[0] == $id_graduation) ? 'checked="checked"' : '' ?>/> 
                                Sim
                            </label>
                            <label><input type="radio" name="data[relation_graduation_<?php echo $i; ?>]" value="0" <?php echo ($val_pos[0] != $id_graduation) ? 'checked="checked"' : '' ?> />Não</label>
                        </div>
                        <hr>
                    <?php
                    $i++;
                endforeach;
                ?>
            </ul>       
        </p>
        <p>    
        <h3 class="hndle">Cursos de Mestrado relacionados:</h3>         
            <ul>
            <br/>
            <?php
                $i=0;
                foreach ($phds->posts as $key => $phd):

                    $id_phd = $phd->ID;

                    $url = get_post_permalink($id_phd);

                    $args = get_post_meta($id_course_current, 'relation_phd_'.$i, true);
                    
                    $val_phd = explode('|', $args);

                    ?>         
                    <li style="font-size:14px;"><p><?php echo $phd->post_title; ?></p></li>
                        <div class="status" style="position: relative;right: 225px;top: -25px;float: right;">
                            <label><input type="radio" name="data[relation_phd_<?php echo $i; ?>]" 
                                value="<?php echo $phd->ID; ?>|<?php echo $url; ?>|<?php echo $phd->post_title; ?>"
                                <?php echo ($val_phd[0] == $id_phd) ? 'checked="checked"' : '' ?>/> 
                                Sim
                            </label>
                            <label><input type="radio" name="data[relation_phd_<?php echo $i; ?>]" value="0" <?php echo ($val_phd[0] != $id_phd) ? 'checked="checked"' : '' ?> />Não</label>
                        </div>
                        <hr>
                    <?php
                    $i++;
                endforeach;
                ?>
            </ul>       
            </p>
    <?php
    }

    public function saveCustomFields($postId) {

        // Verificando se é um AUTOSAVE
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;

        // if our nonce isn't there, or we can't verify it, bail 
        if (!isset($_POST['meta_box_nonce']) || !wp_verify_nonce($_POST['meta_box_nonce'], 'my_meta_box_nonce'))
            return;

        //verificando se o usuário pode editar o post
        if (!current_user_can('edit_post'))
            return;

    

        if (isset($_FILES["grid_course"]) && $_FILES["grid_course"]['name'] != "") {

            $upload = wp_handle_upload($_FILES["grid_course"], array('test_form' => false));

            update_post_meta($postId, "grid_course", $upload["url"]);
        }


        foreach ($_POST['data'] as $key => $value) {

            update_post_meta($postId, $key , $value);
               
        }
            
        foreach ($this->fields as $field) {

            if (isset($_POST[$field])) {

                update_post_meta($postId, $field, $_POST[$field]);
            }
        }

    }
}
?>