<?php
class Levels{
    
    public function getLevels($options = array()){
        
        $args = array("post_type"=>"levels","orderby"=>"post_title","order"=>"ASC","posts_per_page"=>-1);
        
        foreach($options as $key => $option){
            
            $args[$key] = $option;
            
        }
        
        return new WP_Query($args);
    }
    
    public function getListLevels($options = array()){
        
        $data = self::getlevels($options);
        
        $areas = array();
        
        while($data->have_posts()){
            $data->the_post();
            $areas[get_the_ID()] = get_the_title(); 
        }
        
        wp_reset_postdata();
        
        return $areas;
        
        
    }
    
    public function getLevelById($unit_id){
        
        $args = array("p"=>$unit_id);
        
        return new WP_Query($args);
        
        
    }
    
   
    public function createCustomPostType(){
        
        register_post_type('levels', array(	
            'label' => 'Níveis',
            'description' => 'Cadastro de Nível',
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'rewrite' => array('slug' => 'nivel-ensino'),
            'query_var' => true,
            'menu_position' => 10,
            'supports' => array('title','editor','thumbnail'),
            'menu_icon' => get_bloginfo("stylesheet_directory").'/wp5/img/icon-areas.png',
            'labels' => array (
                'name' => 'Níveis',
                'singular_name' => 'Nível',
                'menu_name' => 'Níveis',
                'add_new' => 'Novo Nível',
                'add_new_item' => 'Novo Nível',
                'edit' => 'Editar',
                'edit_item' => 'Editar Nível',
                'new_item' => 'Novo Nível',
                'view' => 'Ver Nível',
                'view_item' => 'Ver Nível',
                'search_items' => 'Buscar Níveis',
                'not_found' => 'No Destaques Found',
                'not_found_in_trash' => 'No Destaques Found in Trash',
                'parent' => 'Parent Nível',
            ),
        ));
        
        flush_rewrite_rules();
        add_action( 'add_meta_boxes', array(&$this, 'addCustomFields' ));
      	add_action( 'save_post', array(&$this, 'saveCustomFields' ));
        
    }
      

    public function addCustomFields(){
        
        add_meta_box("levelCustomFields","Dados do Nível",array(&$this,"formCustomFields"),"levels","normal","low");
    
    }
    
    public function saveCustomFields($postId){
        
        if(defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return; 

        if(!isset($_POST['meta_box_nonce']) || !wp_verify_nonce($_POST['meta_box_nonce'],'my_meta_box_nonce')) return; 

        if(!current_user_can('edit_post')) return;
        
        if(isset($_POST['info_level']))
            update_post_meta( $postId,'info_level',$_POST['info_level']); 
       
    }
    
    public function formCustomFields(){
        
        global $post;
        
        $data = get_post_custom($post->ID);
        
        $info_level = (isset($data["info_level"])) ? $data["info_level"][0] : '';
    
        wp_nonce_field('my_meta_box_nonce','meta_box_nonce');
        
        ?>
        <p>
            <label for="infoLevel">Mais Informações:</label>
            <?php wp_editor($info_level,"infoLevel",array("textarea_name"=>"info_level"));?>
        </p>
        <?php
    }
    
}
?>