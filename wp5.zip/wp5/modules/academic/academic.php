<?php
require_once("units.php");
require_once("areas.php");
require_once("coordinators.php");
require_once("courses.php");
require_once("graduations.php");
require_once("phds.php");
require_once("levels.php");
require_once("projects.php");
require_once("extensions.php");
require_once("diary.php");
require_once("ead.php");


class Academic{
    
    public static $Units = null;
    
    public static $Areas = null;
    
    public static $Coordinators = null;
    
    public static $Courses = null;

    public static $Graduations = null;

    public static $Phds = null;
    
    public static $Levels = null;
    
    public static $Projects = null;

    public static $Extensions = null;

    public static $Agendas = null;

    public static $Eads = null;


    public function Academic(){
        
        $this->Units = new Units;
        
        $this->Areas = new Areas;
        
        $this->Coordinators = new Coordinators;
        
        $this->Courses = new Courses;

        $this->Graduation = new Graduations;
        
        $this->Phd = new Phds;

        $this->Levels = new Levels;

        $this->Projects = new Projects;
        
        $this->Extensions = new Extensions;

        $this->Agendas = new Agendas;

        $this->Eads = new Eads;

        $this->setCustomPosts();
        
    }
    
    public function setCustomPosts(){
        
        $this->Units->createCustomPostType();
        
        $this->Areas->createCustomPostType();
        
        $this->Coordinators->createCustomPostType();
        
        $this->Courses->createCustomPostType();

        $this->Graduation->createCustomPostType();

        $this->Phd->createCustomPostType();
        
        $this->Levels->createCustomPostType();

        $this->Projects->createCustomPostType();

        $this->Extensions->createCustomPostType();

        $this->Agendas->createCustomPostType();

        $this->Eads->createCustomPostType();

        
    }
    
    public function getUnits(){
        self::$Units = new Units();
        
        return self::$Units->getUnits();
    }
    
}
?>