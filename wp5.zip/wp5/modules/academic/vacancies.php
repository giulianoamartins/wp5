<?php

class Vacancies {

    public $fields = array(
        "area_course",
        "unit_vacancies",
        "level_course",
        "coordinator_course",
        "formation_course",
        "duration_course",
        "modality_course",
        "workload_course",
        "hour_course",
        "mec_course",
        "cost_course",
        "activities",
        "location_course",
        "info_course",
        "additional_information",
        "evaluation_course",
        "grid_course",
        "release_year",
        "blog_course",
        "course_recognition",
        "relation_course_",
        "relation_graduation_"
    );

    public function getVacancies($options = array()) {

        $args = array("post_type" => "vacancies", "orderby" => "title", "order" => "ASC", "posts_per_page" => -1);

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);
    }

    public function getListVacancies($options = array()) {

        $data = self::getVacancies($options);

        $vacancies = array();

        while ($data->have_posts()) {
            $data->the_post();
            $vacancies[get_the_ID()] = get_the_title();
        }

        return $vacancies;
    }

    // public function getVacanciesById($course_id) {

    //     $args = array("p" => $course_id);

    //     return new WP_Query($args);
    // }

    public function getVacanciesByUnit($unit_id = null, $options = array()) {

        $args = array(
            "post_type" => "courses",
            "orderby" => "title",
            "order" => "ASC",
            "posts_per_page" => -1,
            "meta_query" => array(
                array("key" => "unit_vacancies",
                    "value" => $unit_id)
            )
        );

        foreach ($options as $key => $option) {

            $args[$key] = $option;
        }

        return new WP_Query($args);
    }

    // public function getVacanciesByArea($area_id = null, $options = array()) {

    //     $args = array(
    //         "post_type" => "courses",
    //         "orderby" => "title",
    //         "order" => "ASC",
    //         "posts_per_page" => -1,
    //         "meta_query" => array(
    //             array("key" => "area_course",
    //                 "value" => $area_id)
    //         )
    //     );

    //     foreach ($options as $key => $option) {

    //         $args[$key] = $option;
    //     }

    //     return new WP_Query($args);
    // }

    
    // public function getListVacanciesByArea($area_id = null) {

    //     $data = self::getCoursesByArea($area_id);

    //     $courses = array();

    //     while ($data->have_posts()) {
    //         $data->the_post();
    //         $courses[get_the_ID()] = get_the_title();
    //     }

    //     return $courses;
    // }

    // public function getVacanciesByLevel($level_id = null, $options = array()) {

    //     $args = array(
    //         "post_type" => "courses",
    //         "orderby" => "title",
    //         "order" => "ASC",
    //         "posts_per_page" => -1,
    //         "meta_query" => array(
    //             array("key" => "level_course",
    //                 "value" => $level_id)
    //         )
    //     );

    //     foreach ($options as $key => $option) {

    //         $args[$key] = $option;
    //     }
    //     //debug($args);
    //     return new WP_Query($args);
    // }

    // public function getVacanciesByAreaAndLevel($area_id = null, $level_id = null, $options = array()) {


    //     $args = array(
    //         "post_type" => "courses",
    //         "orderby" => "title",
    //         "order" => "ASC",
    //         "posts_per_page" => -1,
    //         "meta_query" => array(
    //             array("key" => "area_course",
    //                 "value" => $area_id),
    //             array("key" => "level_course",
    //                 "value" => $level_id)
    //         )
    //     );

    //     foreach ($options as $key => $option) {

    //         $args[$key] = $option;
    //     }

    //     return new WP_Query($args);
    // }

    // public function getVacanciesByMeta($metaArr,$options=array()){

    //     $args = array(
    //         "post_type" => "courses",
    //         "orderby" => "title",
    //         "order" => "ASC",
    //         "posts_per_page" => -1
    //     );

    //     $args["meta_query"] = array();

    //     foreach($metaArr as $key => $value){

    //         $args["meta_query"][]= array(
    //             "key"=>$key,
    //             "compare"=>"=",
    //             "value"=>$value
    //         );

    //     }


    //     foreach ($options as $key => $option) {

    //         $args[$key] = $option;
    //     }

    //     return new WP_Query($args);

    // }

    public function createCustomPostType() {

        register_post_type('vacancies', array(
            'label' => 'Lista de Vagas',
            'description' => 'Cadastro de Vagas',
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'rewrite' => array('slug' => 'vagas'),
            'query_var' => true,
            'menu_position' => 10,
            'supports' => array('title', 'editor', 'thumbnail'),
            'menu_icon' => get_bloginfo("stylesheet_directory") . '/wp5/img/icon-courses.png',
            'labels' => array(
                'name' => 'Vagas',
                'singular_name' => 'Vagas',
                'menu_name' => 'Vagas',
                'add_new' => 'Novo Vagas',
                'add_new_item' => 'Novo Vagas',
                'edit' => 'Editar',
                'edit_item' => 'Editar Vagas',
                'new_item' => 'Novo Vagas',
                'view' => 'Ver Vagas',
                'view_item' => 'Ver Vagas',
                'search_items' => 'Buscar Cursos',
                'not_found' => 'No Destaques Found',
                'not_found_in_trash' => 'No Destaques Found in Trash',
                'parent' => 'Parent Vagas',
            ),
        ));

        add_filter('manage_edit-vacancies_columns',array(&$this,"manageCustomColumn"));
        add_action('manage_vacancies_posts_custom_column',array(&$this,"manageCustomColumnContent"),10,2);
        add_action('add_meta_boxes', array(&$this, 'addCustomFields'));
        add_action('save_post', array(&$this, 'saveCustomFields'));
    }
    public function manageCustomColumn($columns){
        
        unset($columns["date"]);
        
        $columns["unit"] = "Unidade";
        $columns["date"] = "Data";
        
        return $columns;
        
    }
    
    public function manageCustomColumnContent($column,$post_id){
        
        if($column=="unit"){
            $unit_id = get_post_meta($post_id,"unit_vacancies",true);
            if($unit_id!=""){
                echo get_the_title($unit_id);
            }else{
                echo "";
            }
        }
        
    }

    public function addCustomFields() {

        add_meta_box("courseCustomFields", "Listagem de Vagas", array(&$this, "formCustomFields"), "vacancies", "normal", "low");
    }

    public function formCustomFields() {

        global $post;

        $data = get_post_custom($post->ID);


        foreach ($this->fields as $field) {
            $$field = (isset($data[$field])) ? $data[$field][0] : '';
        }

        $grid_vacancies = (isset($data["grid_vacancies"])) ? $data["grid_vacancies"][0] : '';

        wp_nonce_field('my_meta_box_nonce', 'meta_box_nonce');


global $wpdb;
$consulta =  $wpdb->get_results ("SELECT * FROM wp_vagas ORDER BY vacancy_id ASC");
?>
<input type="hidden" name="count" value="<?php echo $count; ?>" />
<?php

    for ($i=0; $i < count($consulta) ; $i++): 
    //pegar o valor do campo status da vaga no banco de dados   
    $status_vacancie = $consulta[$i]->status;
    ?>
    <h2><?php echo $consulta[$i]->vacancy; ?></h2>
    <div class="box-content">
        <div class="header" style="background: #F1F1F1;width: 90%;padding: 8px;">
           
            <input type="hidden" name="data[vaga][vacancy_id][<?php echo $i?>]" value="<?php echo $consulta[$i]->vacancy_id; ?>">

            <div class="enterprise" style="width:420px;float:left;">
                <label>Nome da Empresa:</label><br/>
                <input type="text" name="company_name" value="<?php echo $consulta[$i]->enterprise; ?>" style="width: 400px;" />
            </div>
            <div class="status">
                <label>Status da Vaga:</label><br/>

                <label><input type="radio" name="data[vaga][status][<?php echo $i; ?>]" value="0"<?php echo ($data['vaga']['status']['<?php echo $i; ?>'] == $status_vacancie) ? 'checked="checked"' : ''; ?>/> Inativo</label>            
                <label><input type="radio" name="data[vaga][status][<?php echo $i; ?>]" value="1"<?php echo ($data['vaga']['status']['<?php echo $i; ?>'] == $status_vacancie) ? 'checked="checked"' : ''; ?>/> Ativo</label>
                <label><input type="radio" name="data[vaga][status][<?php echo $i; ?>]" value="2"<?php echo ($data['vaga']['status']['<?php echo $i; ?>'] == $status_vacancie) ? 'checked="checked"' : ''; ?>/> Deletar</label>
            </div>
            <p style="text-decoration:underline;cursor:pointer;color:#2EA2CC;">+ Detalhes</p>
        </div>
        <div class="accordion" style="background:#F1F1F1;width:90%;margin:10 auto;padding:8px;">
            <ul>
            
                <li>
                    <p>
                        <label>Responsável:</label><br/>
                        <input type="text" name="response_name" value="<?php echo $consulta[$i]->response; ?>" style="width: 400px;" />
                    </p>
                </li>
                <li>
                    <p>
                        <label>Email:</label><br/>
                        <input type="text" name="company_name" value="<?php echo $consulta[$i]->email; ?>" style="width: 400px;" />
                    </p>
                </li>
                <li>
                    <p>
                        <label>Telefone:</label><br/>
                        <input type="text" name="company_name" value="<?php echo $consulta[$i]->phone; ?>" style="width: 400px;" />
                    </p>
                </li>
                <li>
                    <p>
                        <label>Titulo da Vaga:</label><br/>
                        <input type="text" name="company_name" value="<?php echo $consulta[$i]->vacancy; ?>" style="width: 400px;" />
                    </p>
                </li>
                <li>
                    <p>
                        <label>Area:</label><br/>
                        <input type="text" name="area_job" value="<?php echo $consulta[$i]->area; ?>" style="width: 400px;" />
                    </p>
                </li>
                <li>
                    <p>
                        <label>Descição da Vaga:</label><br/>
                        <textarea name="message" style="width: 400px;"><?php echo $consulta[$i]->message; ?></textarea>
                    </p>
                </li>
                <li>
                    <p>
                        <label>Data da Inclusão da Vaga:</label><br/>
                        <input type="date" name="inclusion_of_the_vacancy" value="<?php echo $consulta[$i]->date_inclusion; ?>" style="width: 400px;" />
                    </p>
                </li>
                <li>
                    <p>
                        <label>Data Limite para Candidatura a Vaga:</label><br/>
                        <input type="date" name="limit_for_job_application" value="<?php echo $consulta[$i]->date_limit; ?>" style="width: 400px;" />
                    </p>
                </li>
            </ul>
        </div>
    </div>
<hr/>
    <?php
    endfor;
}

    public function saveCustomFields($postId) {

        // Verificando se é um AUTOSAVE
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;

        // if our nonce isn't there, or we can't verify it, bail 
        if (!isset($_POST['meta_box_nonce']) || !wp_verify_nonce($_POST['meta_box_nonce'], 'my_meta_box_nonce'))
            return;

        //verificando se o usuário pode editar o post
        if (!current_user_can('edit_post'))
            return;

    

        if (isset($_FILES["grid_vacancies"]) && $_FILES["grid_vacancies"]['name'] != "") {

            $upload = wp_handle_upload($_FILES["grid_vacancies"], array('test_form' => false));

            update_post_meta($postId, "grid_vacancies", $upload["url"]);
        }


        foreach ($_POST['data'] as $key => $value) {

            update_post_meta($postId, $key , $value);
               
        }
            
        foreach ($this->fields as $field) {

            if (isset($_POST[$field])) {

                update_post_meta($postId, $field, $_POST[$field]);
            }
        }

    }
}
?>